
<?php
require_once ("header.php");
session_start();
 
//function to delete session info and cookies here                   
function deleteUserInfo(){
					    session_unset();
                        session_destroy();
                        setcookie("loggedIn","",time()-3600);
                        $expire = time() + 10 * 60;
                        $path = "/~sxr3531/";
                        $domain = "serenity.ist.rit.edu";
                        $secure = false;
                        $http_only = false;
                        setcookie("loggedOut","true",$expire, $path, $domain, $secure, $http_only);

                        //at first display message telling user they're logged out
                        echo "<p class=color:red';>You are logged out !</p>";

                        //redirect to the login page
                        header('Location:Index.php');
                        exit();

                    }
      /*allow adding and editing of products only if the admin is logged in and phpsessionid and session variables are set
    otherwise redirect to a Index.php i.e the login page if the admin isn't already logged in*/
 	 $db = DB::getInstance();
      	if(isset($_COOKIE['PHPSESSID']) && isset($_SESSION['loggedIn']) && !isset($_SESSION['loggedOut'])) {
      	if(isset($_COOKIE['loggedIn']))
      	{
      	$last_login = $_COOKIE['loggedIn'];
      	
                        //logged in successfully as admin
                        echo "<p style='background-color:red;color:white'>You logged in on ".$last_login."<p><br/>";
                        }
                   		echo "<button type='button' class='btn btn-primary'><a style='color:white' href='admin.php?loggingout=true'>Log Out</a></button>";
        $db = DB::getInstance();
       

        //Edit an existing product
        if (isset($_POST['addsubmit'])) {
            Product::addProduct();
        }

        //populate dropdown with the existing products for editing data
        
                    $products = array();
		// select all products
            if($stmt = $db->connection->prepare("SELECT * FROM Product")){
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id, $pname,$pdesc, $iname, $oprice, $sprice,$qty);
                //echo $stmt->num_rows;
                if($stmt->num_rows > 0){
                    while($stmt->fetch()){
                        $products[] = array('id' => $id, 'pname' => $pname,'pdesc'=>$pdesc, 'iname' => $iname, 'oprice' => $oprice,'sprice'=>$sprice ,'qty'=>$qty);
                    }
                }
            }
            
        
        
        
        

        

        foreach ($products as $product) {
            	$productoptions[] = $product['pname'];
         
           		 $loadproducts[$product['id']] = implode(", ", $productoptions);
            	unset($productoptions);
        }

        //when clicking on "Select Food " button populate the edit form with the existing slected product details
        if (isset($_POST['selectsubmit'])) {
            $selectedpid = $_POST['selectproduct'];
			$pdata=array();
			//select the product selected
            if($stmt = $db->connection->prepare("SELECT * FROM Product where ProductID=?")){
            $stmt->bind_param('i',intval($selectedpid));
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id, $pname,$pdesc, $iname, $oprice, $sprice,$qty);
              //  echo $stmt->num_rows;
                if($stmt->num_rows > 0){
                    while($stmt->fetch()){
                        $pdata[] = array('id' => $id, 'pname' => $pname,'pdesc'=>$pdesc,'iname' => $iname, 'oprice' => $oprice,'sprice'=>$sprice ,'qty'=>$qty);
                    }
                }
            }
            
          

           

            $pid = $pdata[0]['id'];
            $name = $pdata[0]['pname'];
            $description = $pdata[0]['pdesc'];
           //  $image_name = $pdata[0]['iname'];
            $price = $pdata[0]['oprice'];
             $saleprice = $pdata[0]['sprice'];
            $quantity = $pdata[0]['qty'];
           
          

        }
        else
        {
        //initially keep all the fields blank if no product is selected
        $pid = '';
            $name = '';
            $description = '';
           //  $image_name = $pdata[0]['iname'];
            $price = '';
             $saleprice = '';
            $quantity = '';
            }
           

        //when clicked on edit submit button update the existing product
        if (isset($_POST['editsubmit'])) {
        //called the editProduct method of the Product class
            Product::editProduct();
        }

    }else{
    if(!isset($_SESSION['loggedIn']) || isset($_COOKIE['loggedOut'])){
        header("Location:Index.php");
        exit();
        }
    }
     if(isset($_GET['loggingout'])){
                        //when user clicks on the log out option
                       
                        deleteUserInfo();
                    }

?>
 <div class="container">
     <div>
         <h3><div >Edit an existing product</div></h3>
        <div>
             <form name="producteditform" method="post" action="admin.php">
                 <div class="form-group">
                     <div>
                         <label for="productselect" >Select a product</label>
                     </div>
                    <div>
                         <select class="form-control" name="selectproduct" id="selectproduct">
                            <?php foreach ($loadproducts as $id=>$option){ ?>
                                 <option value="<?php echo $id ?>"><?php echo $option ?></option>
                              <?php } ?>
                         </select>
                    </div>
                     <br>
                    <div>
                        <button type="submit" name="selectsubmit" class="btn btn-primary"> Select Food </button>
                    </div>
                </div>
         </form>
        <br /> <br />
             <form action="admin.php" method="post" enctype="multipart/form-data">
			 <div class="form-group">
                 <div>
                    <label for="name">Name </label>
                 </div>
                 <div>
                     <input class="form-control" type="text"  id="editName" name="editName" value="<?= $name ?>" required/><br>
                 </div>
             </div>
             <div class="form-group">
                	<div>
                	 <label for="Description"> Description </label>
            	  </div>
            	 <div>
                 	 <textarea class="form-control" id="editDescription" name="editDescription" required ><?= $description ?></textarea><br>
            	 </div>
             </div>
              <div class="form-group">
                     <div>
                          <label for="image"  > Upload an Image</label>
                     </div>
                     <div>
                         <input class="form-control" type="file"  name="ProductImage" id="ProductImage" required/>
                     </div>
                 </div>

             <div class="form-group">
                     <div>
                         <label for="price"> Price </label>
                     </div>
                     <div>
                         <input class="form-control" type="number" step="0.01" id="editPrice" name="editPrice" min="0" max="100" value="<?= $price ?>" required /><br>
                     </div>
             </div>
            <div class="form-group">
              <div>
                 <label for="saleprice"> Discounted Price</label>
             </div>
                 <div>
                  <input class="form-control" type="number" step="0.01" name="editSalePrice" id="editSalePrice" min="0" value="<?= $saleprice ?>"  />
                 </div>
             </div>
             <div class="form-group">
                 	 <div>
                          <label for="quantity"> Quantity</label>
                     </div>
                     <div>
                          <input class="form-control" type="number" name="editQuantity" id="editQuantity" min="1" max="100" value="<?= $quantity ?>" required/>
                     </div>
                </div>
           
                
                     <input type="hidden"  name="editId" id="editId" value="<?=$pid ?>"/>
                     <button type="submit" name="editsubmit" class="btn btn-primary"> Submit Changes </button>
             </form>
          </div>
      </div>
  </div>


         <div class="container">
             <div>
                 <h3><div>Add a product</div></h3>
                 <div >
                     <form name="productaddform" action="admin.php" method="post" enctype="multipart/form-data">
                         <div class="form-group">
                             <div>
                                 <label for="name">Name </label>
                             </div>
                             <div>
                                 <input class="form-control" type="text" id="name" name="name" required/><br>
                             </div>
                         </div>
                         <div class="form-group">
                             <div>
                                 <label for="description"> Description </label>
                             </div>
                             <div>
                             <textarea class="form-control" id="description" name="description"  required ></textarea><br>
                            </div>
                          </div>
                        
                         <div class="form-group">
                              <div >
                                 <label for="image" > Upload an Image</label>
                             </div>
                             <div>
                                 <input class="form-control" type="file" name="ProductImage" id="ProductImage" required/>
                             </div>
                         </div>

                         <div class="form-group">
                             <div>
                                 <label for="price" > Price </label>
                             </div>
                             <div>
                                 <input class="form-control" type="number" step="0.01"  id="price" name="price" min="0" max="100" required /><br>
                             </div>
                         </div>
                           <div class="form-group">
                             <div >
                                  <label for="saleprice" > Discounted Price</label>
                            </div>
                            <div>
                                  <input class="form-control" type="number" step="0.01" name="saleprice" id="saleprice" min="0" value="0.0" />
                             </div>
                         </div>
                         <div class="form-group">
                             <div>
                                <label for="quantity" > Quantity</label>
                            </div>
                             <div >
                                 <input class="form-control" type="number" name="quantity" id="quantity" min="1" max="100" required/>
                             </div>
                        </div>
                         <button type="submit" name="addsubmit" class="btn btn-primary"> Submit Product </button>
                         <button type="reset" name="resetsubmit" class="btn btn-secondary"> Reset </button>
                      </form>
                 </div>
            </div> 


