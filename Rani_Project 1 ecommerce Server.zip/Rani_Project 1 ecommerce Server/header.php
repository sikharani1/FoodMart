<?php
require "DB.class.php";
include ("Sanitize.php");
require "Lib_project1.php";
?>

<html>
    <head>
        
        <meta charset="utf-8">
        
        <title>FoodKart</title>

        

        <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
        <script src="alertify.js-0.3.11/lib/alertify.min.js"></script>
		<link rel="stylesheet" href="alertify.js-0.3.11/themes/alertify.core.css" />
		<link rel="stylesheet" href="alertify.js-0.3.11/themes/alertify.default.css" />
		<link href="//netdna.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css" rel="stylesheet" >
		<link href="jquery-confirm-master/css/jquery-confirm.css" rel="stylesheet">
		<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
		<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="jquery-confirm-master/js/jquery-confirm.js"></script>
        <link href="style.css" rel="stylesheet">
     

        
      

    </head>
    <body>
        <nav class="navbar">
            <div class="navcontainer">
                <div style="padding:10px;width:100%;margin:10px;" class="navbar-header">
                   <h1 style='background-color:red'><a class="navbar-name" href="./Index.php">Foodkart</a></h1>
                   
            
                
                <div style="margin:10px;display:block;">
        
                    <ul class="nav navbar" style="margin:10px;">
                    
                        <li class="navele" style="list-style-position:inside;border: 1px solid #22527b;width:20%;color:black "><a style="color:black;background-color:#337ab7" href="./Index.php"><i style="color:black" class="fa fa-home fa-fw fa-2x" aria-hidden="true"></i>Home</a></li>
                        <li class="navele" style="list-style-position:inside;border: 1px solid #22527b;width:20%;color:black"><a  style="color:black;background-color:#337ab7" href="./cart.php"><i style="color:black" class="fa fa-shopping-cart fa-fw fa-2x" aria-hidden="true"></i>Cart</a></li>
                        <li class="navele" style="list-style-position:inside;border: 1px solid #22527b;width:20%;color:black"><a style="color:black;background-color:#337ab7" href="./admin.php"><i  style="color:black" class="fa fa-user fa-fw fa-2x" aria-hidden="true"></i>Admin</a></li>
                      

                    </ul>
                </div>
            </div>
        </nav>
    </body>
</html>

