<?php 
    class DB{
        public $connection;
		private static $db_instance;

        function __construct(){
            $this->connection = new mysqli($_SERVER['DB_SERVER'], $_SERVER['DB_USER'], $_SERVER['DB_PASSWORD'], $_SERVER['DB']);

            if($this->connection->connect_error){
                echo "Connection Failed! " . mysqli_connect_error();
                die();
            }
        }
        public static function getInstance() {
        if ( !self::$db_instance ) {
            self::$db_instance = new DB();
        }

        return self::$db_instance;
    }
//-----------------function to get all the products from the product table.-------------------------------------------------------------------------------

        function getAllProducts(){
            $allproductdata = array();

            if($stmt = $this->connection->prepare("SELECT * FROM Product")){
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id, $pname,$pdesc, $iname, $oprice, $sprice,$qty);
               // echo $stmt->num_rows;
                if($stmt->num_rows > 0){
                    while($stmt->fetch()){
                        $allproductdata[] = array('id' => $id, 'pname' => $pname,'pdesc'=>$pdesc, 'iname' => $iname, 'oprice' => $oprice,'sprice'=>$sprice ,'qty'=>$qty);
                    }
                }
            }
            return $allproductdata;
        }
        function insert($pname, $iname, $oprice,$sprice,$qty){
            $queryString = "INSERT into Product (ProductName,ProductDesc,ImageName,OriginalPrice,SalePrice,Quantity) values (?,?,?,?,?,?)";
            $insertId = -1;

            if($stmt = $this->connection->prepare($queryString)){
                $stmt->bind_param("sssddi", $pname,$pdesc, $iname, $oprice, $sprice,$qty);
                $stmt->execute();
                $stmt->store_result();
                $insertId = $stmt->insert_id;
            }

            return $insertId;
        }
 //-------------------function to get all items from the cart table-------------------------------------------------------------------------------------------------               
        function getAllCart(){
            $allcartdata = array();
			 
            if($stmt = $this->connection->prepare("SELECT * FROM Cart")){
            	//echo "connection";
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id, $pname,$pdesc, $iname, $oprice, $sprice,$qty);
               
                if($stmt->num_rows > 0){
                    while($stmt->fetch()){
                        $allcartdata[] = array('id' => $id, 'pname' => $pname,'pdesc'=>$pdesc, 'iname' => $iname, 'oprice' => $oprice,'sprice'=>$sprice,'qty'=>$qty);
                      
                    }
                }
            }
            return $allcartdata;
        }
//-------------------------------------function to add the item selected from sales/catalog on the index page to the cart table------------------------------------------------------        
        function addtocart($id){
         
        //add products to cart page when clicking on add to cart..
       
		 
			
        $currentproductdata = array();

            if($stmt = $this->connection->prepare("SELECT * FROM Product where ProductID=?")){
            	//echo "connection set";
            	$stmt->bind_param("i", intval($id));
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id, $pname,$pdesc, $iname, $oprice, $sprice,$qty);
                
               
                    while($stmt->fetch()){
                        $currentproductdata[] = array('id' => $id, 'pname' => $pname,'pdesc'=>$pdesc, 'iname' => $iname, 'oprice' => $oprice,'sprice'=>$sprice,'qty'=>$qty );
                        
                    }
                
            }
            $currentcartdata=array();
              if($stmt = $this->connection->prepare("SELECT * FROM Cart where ProductID=?")){
            //	echo "connection set";
            	$stmt->bind_param("i", intval($id));
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id, $pname,$pdesc, $iname, $oprice, $sprice,$qty);
                $nexistingrowscart=$stmt->num_rows;
                
               
                    while($stmt->fetch()){
                        $currentcartdata[] = array('id' => $id, 'pname' => $pname, 'pdesc'=>$pdesc,'iname' => $iname, 'oprice' => $oprice,'sprice'=>$sprice,'qty'=>$qty );
                        
                    }
                
            }
    //echo $currentproductdata[0]['qty'];
    
    if($currentproductdata[0]['qty']==0)
    {
            
       echo "<script type='text/javascript'> 
                        function outofstockerror(){ 
                            setTimeout(
                            function(){
                            alertify.alert(
                            'Oops!,product not available any more'
                            );
                            },
                                400);
                            }
                        outofstockerror();
                        </script>";
     }
     else
    {
        if ($nexistingrowscart==0)
        {
        
       
        	//echo "new product added to cart";

            $queryString = "INSERT into Cart (ProductID,ProductName,ProductDesc,ImageName,OriginalPrice,SalePrice,Quantity) values (?,?,?,?,?,?,?)";
            $insertId = -1;
           // echo "check sale price";
          //  echo $currentproductdata[0]['sprice'];
            $currentcartdata[0]['qty']=1;

            
           // echo "this product is on sale";
            if($stmt = $this->connection->prepare($queryString)){
            	//echo "connection done";
            //	echo $currentproductdata[0]['id'];
                $stmt->bind_param("isssddi", $currentproductdata[0]['id'],$currentproductdata[0]['pname'],$currentproductdata[0]['pdesc'], $currentproductdata[0]['iname'], $currentproductdata[0]['oprice'], $currentproductdata[0]['sprice'],$currentcartdata[0]['qty']);
                $stmt->execute();
                $stmt->store_result();
                $insertId = $stmt->insert_id;
               // echo $insertId."<br/>";
                		}
            
                //echo "updating product quantity decreasing by one"; 
            $queryString = "Update Product Set Quantity = ? where ProductID=?";

        
          // echo "old quantity->".$currentproductdata[0]['qty'];
            
            $currentproductdata[0]['qty']=intval($currentproductdata[0]['qty'])-1;
          // echo "new quanity->".$currentproductdata[0]['qty'];
         
            if($currentproductdata[0]['qty']==0)
            {
             echo "<script type='text/javascript'> 
                        function outofstock_error(){ 
                            setTimeout(
                            function(){
                            alertify.alert(
                            'Woho!,you got the last available item in this product'
                            );
                            },
                                500);
                            }
                        outofstock_error();
                        </script>";
            
            //product not available any more;
            }
             if(!doubleval($currentproductdata[0]['sprice'])) {
            //saleprice is zero;
            if($stmt = $this->connection->prepare($queryString)){
            	//echo "connection done";
            	//echo $currentproductdata[0]['id'];
                $stmt->bind_param('ii',$currentproductdata[0]['qty'],$currentproductdata[0]['id']);
                $stmt->execute();
                $stmt->store_result();
                $numRows = $stmt->affected_rows;
            	}
            }
            else
            {
            
            //this was on sale;
            if($stmt = $this->connection->prepare($queryString)){
            	//echo "connection done";
            	//echo $currentproductdata[0]['id'];
                $stmt->bind_param('ii',$currentproductdata[0]['qty'],$currentproductdata[0]['id']);
                $stmt->execute();
                $stmt->store_result();
                $numRows = $stmt->affected_rows;
                }
                
            }
           // echo "number of rows updated in product->".$numRows;
            
            
            
        }
        else
            {
             //echo "This product is already in cart right now"; 
               $queryString = "Update Cart Set Quantity = ? where ProductID=?";

            //updating cart quantity increase by 1;
           // echo "old quantity".$currentcartdata[0]['qty'];
            $currentcartdata[0]['qty']+=1;
            //echo "updated quantity".$currentcartdata[0]['qty'];
             if(!doubleval($currentcartdata[0]['sprice'])) {
           // saleprice is zero;
            if($stmt = $this->connection->prepare($queryString)){
            	//echo "connection done";
            	//echo $currentcartdata[0]['id'];
                $stmt->bind_param('ii',$currentcartdata[0]['qty'],$currentcartdata[0]['id']);
                $stmt->execute();
                $stmt->store_result();
                $numRows = $stmt->affected_rows;
            	}
            }
            else
            {
            
           // this was on sale;
            if($stmt = $this->connection->prepare($queryString)){
            	//echo "connection done";
            	//echo $currentcartdata[0]['id'];
                $stmt->bind_param('ii',$currentcartdata[0]['qty'],$currentcartdata[0]['id']);
                $stmt->execute();
                $stmt->store_result();
                $numRows = $stmt->affected_rows;
                }
                
            }
            //echo "number of rows updated in cart->".$numRows;
           // updating product quantity decreasing by one"; 
            $queryString = "Update Product Set Quantity = ? where ProductID=?";

           
           // echo "old quantity->".$currentproductdata[0]['qty'];
           
            $currentproductdata[0]['qty']-=1;
        
            //echo "updated quantity".$currentproductdata[0]['qty'];
            if($currentproductdata[0]['qty']==0)
            {
            
          //  product not available any more;
            }
             if(!doubleval($currentproductdata[0]['sprice'])) {
            //echo "saleprice is zero";
            if($stmt = $this->connection->prepare($queryString)){
            	//echo "connection done";
            	//echo $currentproductdata[0]['id'];
                $stmt->bind_param('ii',$currentproductdata[0]['qty'],$currentproductdata[0]['id']);
                $stmt->execute();
                $stmt->store_result();
                $numRows = $stmt->affected_rows;
            	}
            }
            else
            {
            
            //this was on sale;
            if($stmt = $this->connection->prepare($queryString)){
            //	echo "connection done";
            	//echo $currentproductdata[0]['id'];
                $stmt->bind_param('ii',$currentproductdata[0]['qty'],$currentproductdata[0]['id']);
                $stmt->execute();
                $stmt->store_result();
                $numRows = $stmt->affected_rows;
                }
                
            }
            //echo "number of rows updated in product->".$numRows;
            
            
            }
            
    }

    

 }  
 
//-------------------function to get all the authenticated users-------------------------------------------------------------------------------------------       
        function getAllUsers()
        {
        $data = array();
		//getting all authenticated users
            if($stmt = $this->connection->prepare("SELECT * FROM Users")){
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id,$uname,$pwd);
                
                if($stmt->num_rows > 0){
                    while($stmt->fetch()){
                       $data[] = array('id' => $id, 'uname' => $uname, 'pwd' => $pwd);
                        
                    }
                }
            }
            return $data;
        
        
        }
//-------------------------------------function to get all product items data in table form-----------------------------------------------------------------
        function getAllProductsAsTable(){
            $data = $this->getAllProducts();
			//getting all products data in table form
            if(count($data) > 0){
                $bigString = "<form action='Index.php' method='POST'><table border='1'>
                                <tr style='border:solid thin black'><th>Product Id</th><th>Dish Name</th><th>Description</th><th>Image</th><th>Price</th><th>Discounted price</th><th>Quantity</th></tr>";
                
                foreach($data as $row){
                    $bigString .= "<tr><td><a href='cart.php?id={$row['id']}'>{$row['id']}</a></td>
                                    <td>{$row['pname']}</td>
                                      <td>{$row['pdesc']}</td>
                                    <td><div class='holdimg'><img class='productimage' src='assets/{$row['iname']}' /></div></td>
                                    <td>{$row['oprice']}</td>
                                    <td>{$row['sprice']}</td>
                                    <td>{$row['qty']}</td>
                                    <td><button class='btn btn-primary' type='submit' onclick='addtocart({$row['id']})' name='addtocart' value={$row['id']}>Add to cart</button></td>
                                    </tr>";
                }

                $bigString .= "</table>";
            }
            else{
                $bigString = "<h2>No product exist</h2>";
            }

            return $bigString;
        }
//------------------function to get all cart items data in table form--------------------------------------------------------------------------------------
           function getAllCartsAsTable(){
            $cdata = $this->getAllCart();
           // getting cart data;
		//echo count($cdata);
            if(count($cdata) > 0){
                $bigString = "<form class='form' action='cart.php' method='post'><table border='1'>
                                <tr style='border:solid thin black'><th>#Id</th><th>DishName</th><th>Description</th><th>Image</th><th>Price</th><th>DiscountedPrice</th><th>Quantity</th></tr>";
                $price=0.0;
                foreach($cdata as $row){
                  if($row['sprice'])
                        {
                        $price+=($row['sprice'])*($row['qty']);
                        }
                        else
                        {
                        $price+=($row['oprice'])*($row['qty']);
                        }
                    $bigString .= "<tr><td><a href='Index.php?id={$row['id']}'>{$row['id']}</a></td>
                                    <td>{$row['pname']}</td>
                                     <td>{$row['pdesc']}</td>";
                                    if($row['sprice']>0)
                                    {
                                     $bigString .= "<td class='originalprice'>".'$'."{$row['oprice']}</td>";
                                     }else
                                     {
                                     $bigString .= "<td class='cartprice'>".'$'."{$row['oprice']}</td>";
                                     }
                                    
                                    $bigString .="<td class='cartprice'>".'$'."{$row['sprice']}</td>
                                    <td>{$row['qty']}</td>
                                    <td><button class='btn btn-primary' type='submit' onclick='deletefromcart({$row['id']})' name='deletefromcart' value={$row['id']}>Delete from cart</button></td>
                                    </tr>";
                                   
                }

                $bigString .= "</table><h2 class='carttotal' style='margin:1%'>Total price=".$price."</h2>";
                   
           
            $bigString .= "<button class='btn btn-primary' type='submit' onclick='emptycart()' name='emptycart'>Empty cart</button>";
            $bigString .= "</form>";
           // echo $bigString;
            }
            else{
                $bigString = "<h2>No product exist</h2>";
            }
			
            return $bigString;
        }
//--------------------------------------function to empty the cart deleting all items----------------------------------------------------------------------
        function emptycart()
        {
           $cartitems = $this->getAllCart();
         if(count($cartitems) > 0)
         {
       
        

        //increment product quantity back to the original in the products database for each item in the cart
        foreach ($cartitems as $item){
                $id = $item['id'];
                $qty = $item['qty'];
                  if($stmt = $this->connection->prepare("UPDATE Product SET Quantity=Quantity+$qty WHERE ProductID=$id"))
                  {
                              
                $stmt->execute();
                $stmt->store_result();
                 $numRows = $stmt->affected_rows;
                 //echo "number of rows updated".$numRows;
               
            }
            }
            

        //remove all from the cart and redirect user to the home/index page
       		 if($numRows>0) {
             	if($stmt = $this->connection->prepare("DELETE FROM Cart"))
             	{
            		$stmt->execute();
               		 $stmt->store_result();
                 	$numRows = $stmt->affected_rows;
                 //	echo "number of rows deleted".$numRows;
            		header("Location:Index.php");
            		exit();
        		}
        	}
        }
    }
//--------------------------------------function to delete the item selected from the cart------------------------------------------------------------------

   
        //deleting the item selected from the cart
        function deletefromcart($id){

           
        $currentcartdata = array();

            if($stmt = $this->connection->prepare("SELECT * FROM Cart where ProductID=?")){
            //	echo "connection set";
            	$stmt->bind_param("i", intval($id));
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id, $pname,$pdesc, $iname, $oprice, $sprice,$qty);
                $nrows=$stmt->num_rows;
              //  echo $nrows."<br\>";
               
                    while($stmt->fetch()){
                        $currentcartdata[] = array('id' => $id, 'pname' => $pname,'pdesc'=>$pdesc,  'iname' => $iname, 'oprice' => $oprice,'sprice'=>$sprice ,'qty'=>$qty);
                        
                    }
                
            }
            $currentproductdata=array();
               if($stmt = $this->connection->prepare("SELECT * FROM Product where ProductID=?")){
            	//echo "connection set";
            	$stmt->bind_param("i", intval($id));
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id,$pname, $pdesc, $iname, $oprice, $sprice,$qty);
                $nexistingrowsproduct=$stmt->num_rows;
               // echo "existing rows".$nexistingrowsproduct."<br\>";
                
                  while($stmt->fetch()){
                        $currentproductdata[] = array('id' => $id, 'pname' => $pname,'pdesc'=>$pdesc,  'iname' => $iname, 'oprice' => $oprice,'sprice'=>$sprice ,'qty'=>$qty);
                        
                    }
                
        if ($nexistingrowsproduct==0)
        {
          //this product was out of stock; 
        
       
        

            $queryString = "INSERT into Product (ProductID,ProductName,ProductDesc,ImageName,OriginalPrice,SalePrice,Quantity) values (?,?,?,?,?,?,?)";
            $insertId = -1;
           // echo "check sale price";
           // echo $currentcartdata[0]['sprice'];
            if(!doubleval($data[0]['sprice'])) {
            //echo "saleprice is zero";
            if($stmt = $this->connection->prepare($queryString)){
            	//echo "connection done";
            	//echo $currentcartdata[0]['id'];
                $stmt->bind_param("isssddi",$currentcartdata[0]['id'], $currentcartdata[0]['pname'],$currentcartdata[0]['pdesc'], $currentcartdata[0]['iname'], $currentcartdata[0]['oprice'], $currentcartdata[0]['sprice'],$currentcartdata[0]['qty']);
                $stmt->execute();
                $stmt->store_result();
                $insertId = $stmt->insert_id;
               // echo $insertId."<br/>";
           			 }
            }
            else
            {
            //echo "this product is on sale";
            if($stmt = $this->connection->prepare($queryString)){
            //	echo "connection done";
            //	echo $currentproductdata[0]['id'];
                $stmt->bind_param("isssddi", $currentcartdata[0]['id'],$currentcartdata[0]['pname'],$currentcartdata[0]['pdesc'], $currentcartdata[0]['iname'], $currentcartdata[0]['oprice'], $currentcartdata[0]['sprice'],$currentcartdata[0]['qty']);
                $stmt->execute();
                $stmt->store_result();
                $insertId = $stmt->insert_id;
              //  echo $insertId."<br/>";
                		}
            }
        }
        else
            {
               $queryString = "Update Product Set Quantity = ? where ProductID=?";

          //  updating product quantity;
          //  echo "old quantity".$currentproductdata[0]['qty'];
            $currentproductdata[0]['qty']+=$currentcartdata[0]['qty'];
           // echo "updated quantity".$currentproductdata[0]['qty'];
             if(!doubleval($currentproductdata[0]['sprice'])) {
            //saleprice is zero;
            if($stmt = $this->connection->prepare($queryString)){
            	//echo "connection done";
            	//echo $currentproductdata[0]['id'];
                $stmt->bind_param('ii',$currentproductdata[0]['qty'],$currentproductdata[0]['id']);
                $stmt->execute();
                $stmt->store_result();
                $numRows = $stmt->affected_rows;
            	}
            }
            else
            {
            
          //  echo "this was on sale";
            if($stmt = $this->connection->prepare($queryString)){
            	//echo "connection done";
            	//echo $currentproductdata[0]['id'];
                $stmt->bind_param('ii',$currentproductdata[0]['qty'],$currentproductdata[0]['id']);
                $stmt->execute();
                $stmt->store_result();
                $numRows = $stmt->affected_rows;
                }
            }
           // echo "number of rows updated in product".$numRows;
        }
            
            
     }
                
          
             $queryString = "DELETE from Cart WHERE ProductID = ?";
            $numRows = 0;

            if($stmt = $this->connection->prepare($queryString)){
                $stmt->bind_param("i", intval($id));
                $stmt->execute();
                $stmt->store_result();
                $numRows = $stmt->affected_rows;
            }

           // echo "number of rows deleted in product".$numRows."<br/>";
            
        }
//----------------------------function to show initial page and other page navigations-----------------------------------------------------------------------------        

        function showinitialpage($pgno)
        {
         $showcatalogdata = array();
		  $sprice=0;
		   $data=array();
		   if($pgno==0)
		   { $n=5; }
		   else
		   {
		   $n=($pgno)*5;
		   }
		  if($stmt = $this->connection->prepare("SELECT ProductID FROM Product where SalePrice=? order by ProductID limit ?")){
       
       $stmt->bind_param('di',$sprice,$n);
                $stmt->execute();
             $stmt->store_result();
             $stmt->bind_result($id);
			
		//echo "connection done";
             
         if($stmt->num_rows > 0){
                    while($stmt->fetch()){
                        $data[] = array('id' => $id);
                    }
                }
                $maxid=$data[0]['id'];
                 //echo $maxid;
                 foreach($data as $row){
                 if($row['id']>$maxid)
                 {
                 
                 $maxid=$row['id'];
                 }
                 
                // echo $row['id'];
                 
                 
                 
                 }
                  // echo $maxid;
                  return $maxid;
                  }
            }
            
 //---------------------function to display all the catalog items-------------------------------------------------------------------------------------------                       
                function showcatalog($pgno)
                {
                
                
                $maxid=$this->showinitialpage($pgno);
                
                 $showcatalogdata = array();
		 		 $sprice=0;
		 		 if($stmt = $this->connection->prepare("SELECT ProductID FROM Product where SalePrice=$sprice order by ProductID")){
		 		   $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id);
                $noofitems=$stmt->num_rows;
               // echo $noofitems;
                $itemseachpage=5;
                $noofpage=$noofitems/$itemseachpage;
               //echo $noofpage;
                
                }
                if($pgno==0)
                {
                $offset=0;
                }
                else
                {
		 		$offset=$maxid;
		 		//echo $offset;
		 		}
           		 if($stmt = $this->connection->prepare("SELECT * FROM Product where SalePrice=$sprice AND ProductID > $offset order by ProductID limit 5")){
          
             
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id, $pname,$pdesc, $iname, $oprice, $sprice,$qty);
               
                if($stmt->num_rows > 0){
                    while($stmt->fetch()){
                        $showcatalogdata[] = array('id' => $id, 'pname' => $pname,'pdesc'=>$pdesc, 'iname' => $iname, 'oprice' => $oprice,'sprice'=>$sprice ,'qty'=>$qty);
                    }
                }
            }
            return $showcatalogdata;
        
        
        
        
        }
 //---------------------------------------------------------------function to show all catalog items as table---------------------------------------------------------------       
        
        function getAllCatalogAsTable($pgno){
            $allcatalogdata = $this->showcatalog($pgno);

        
            if(count($allcatalogdata) > 0){
                $bigString = "<form class='form' action='Index.php' method='post'><table>
                                <tr style='border:solid thin black'><th>ProductId</th><th>DishName</th><th>Description</th><th>Image</th><th>Price</th><th>SalePrice</th><th>Quantity</th><th></th></tr>";
                
                foreach($allcatalogdata as $row){
                    $bigString .= "<tr><td><a href='cart.php?id={$row['id']}'>{$row['id']}</a></td>
                                    <td class='productname'>{$row['pname']}</td>
                                    <td class='productdesc'>{$row['pdesc']}</td>
                                    <td><div class='holdimg'><img style='width:200px;height:200px' class='productimage' src='assets/{$row['iname']}' /></div></td>
                                    <td  class='price'>".'$'."{$row['oprice']}</td>
                                    
                                    <td  class='quantity'>Only {$row['qty']} left in stock.</td>
                                    <td><button class='btn btn-primary' type='submit' onclick='addtocart({$row['id']})' name='addtocart' value={$row['id']}>Add to cart</button></td>
                                    </tr>";
                }

                $bigString .= "</table>";
            }
            else{
                $bigString = "<h2>No product exist</h2>";
            }

            return $bigString;
        }
 //---------------------function to display all the sale items-------------------------------------------------------------------------------------------       
        function showsale()
        {
         $showsaledata = array();
		  
            if($stmt = $this->connection->prepare("SELECT * FROM Product where SalePrice>0 order by ProductID")){
          
             
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id, $pname,$pdesc, $iname, $oprice, $sprice,$qty);
             //  echo "total numebr of sale->".$stmt->num_rows;
                if($stmt->num_rows > 0){
                    while($stmt->fetch()){
                        $showsaledata[] = array('id' => $id, 'pname' => $pname,'pdesc'=>$pdesc, 'iname' => $iname, 'oprice' => $oprice,'sprice'=>$sprice ,'qty'=>$qty);
                    }
                }
            }
           
            return $showsaledata;
        
        
        
        
        }
//---------------------------------------------------------------function to show all sale items as table--------------------------------------------------
        
        function getAllSaleAsTable(){
            $allsaledata = $this->showsale();

        
            if(count($allsaledata) > 0){
                $bigString = "<form class='form' action='Index.php' method='post'><table>
                              <tr style='border:solid thin black'> <th>#Id</th><th>DishName</th><th>Description</th><th>Image</th><th>Price</th><th>SalePrice</th><th>Quantity</th><th></th></tr>";
                
                foreach($allsaledata as $row){
                    $bigString .= "<tr style='border:solid thin black'><td><a href='cart.php?id={$row['id']}'>{$row['id']}</a></td>
                                    <td class='productname'>{$row['pname']}</td>
                                    <td class='productdesc'>{$row['pdesc']}</td>
                                    <td><div class='holdimg'><img style='width:200px;height:200px' class='productimage' src='assets/{$row['iname']}' /></div></td>
                                    <td class='originalprice'>".'$'."{$row['oprice']}</td>
                                    <td class='discountedprice'>".'$'."{$row['sprice']}</td>
                                    <td class='quantity'>Only {$row['qty']} left in stock</td>
                                    <td><button class='btn btn-primary' type='submit' onclick='addtocart({$row['id']})' name='addtocart' value={$row['id']}>Add to cart</button></td>
                                    </tr>";
                }

                $bigString .= "</table>";
            }
            else{
                $bigString = "<h2>No product exist</h2>";
            }

            return $bigString;
        }
        
        

    }
?>