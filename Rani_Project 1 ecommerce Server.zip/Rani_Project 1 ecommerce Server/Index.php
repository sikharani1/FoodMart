<?php
//including the essential files through the header
require_once "header.php";

session_start();
//getting an instance of the database object
 $db = DB::getInstance();
//redirect to admin page if already session is set from before
if(isset($_SESSION['loggedIn']) && !empty($_SESSION['loggedIn']))
{
	//if session was logged in from before go to the admin page directly
		header('Location:admin.php');
    	exit();
    }
   

else
{
   
    //get credentials for admin and test the entered credentials against that data stored when user presses login link
   	 if(isset($_POST['submit'])){
        
        
       // get all the credentials from the users table 
        	$user_credentials = $db->getAllUsers();
        
		
        //credentials match for each user
        	foreach($user_credentials as $row)
        	{
        //if username and password matches then store the loggedIn session and allow the user
        	if (sanitizeString($_POST['username']) == $row['uname'] && sanitizeString($_POST['password']) ==$row['pwd']){
			
            	        $_SESSION['loggedIn'] = true;
            	        //echo "session variable loggedin".$_SESSION['loggedIn'];
            	        //cookie must expire after 1 month
        	            $expire = time() + 10 * 60;
                        $path = "/~sxr3531/";
                     	$domain = "serenity.ist.rit.edu";
                     	$secure = false;
                     	$http_only = false;
                     	//set the loggedin cookie 
                     	setcookie("loggedIn", date("F j, Y, g:i a"), $expire, $path, $domain, $secure, $http_only);
            	
           		 header('Location:admin.php');
            	
            	exit();
            }
            
     else
         {
                 // check if session is not set because the admin has clicked logOut link 
                if(isset($_COOKIE['loggedOut']) && $_COOKIE['loggedOut']==true){
                         //echo "You need to log in again !";
                        $expire = time() + 10 * 60;
                        $path = "/~sxr3531/";
                        $domain = "serenity.ist.rit.edu";
                        $secure = false;
                        $http_only = false;
                        
                       //set the loggedout cookie 
                        setcookie("loggedOut","false",$expire,$path, $domain, $secure, $http_only);
                          $_SESSION['loggedOut'] = false;
                }
                else
                    {
                    	 //echo "<p style='width:30%;color:white;background-color:red;'>Invalid Login</p>";
                    	 echo "<script type='text/javascript'> 
                        function loginerror(){ 
                            setTimeout(function(){alert('Error logging in Please check your credentials')},500);
                            };
                        loginerror();
                        </script>";
                        
                        // otherwise set the new loggedIn cookie 
                         setcookie('loggedIn', "", time() - (60 * 10));
                    }
         }
    }
        
        
            
                        
            
        
    }
    else
    {
    // unset the session
            session_unset();
           // echo "You need to login.";
           
    }
        
}

?>
<!--Login form for admin-->
        <div>
            <div class="login">
                <h3><div>Admin Login</div></h3>
                <div style="padding:20px;">
                     <form name="adminloginform" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

                         <div>
                             <label>Username</label>
                             <div >
                                  <input type="text"  id="username" name="username"  value="<?php if (isset($_POST['username'])) echo $_POST['username'];?>"  required/><br>
                             </div>
                         </div>
                         <div>
                             <label> Password </label>
                             <div >
                                 <input type="password"  id="password" name="password" required /><?php if (isset($_POST['password'])) echo $_POST['password'];?><br>
                             </div>
                         </div>
                         <br/>
                         <button type="submit" name="submit" class="btn btn-primary">Login</button>
                     </form>
                </div>
            </div>
        </div>
 

<?php
global $string5;
global $string6;
//get all sale products as table
$string5=$db->getAllSaleAsTable();



//check if user clicks add to cart link
 if(isset($_POST['addtocart'])){
  $id= $_POST['addtocart'];
//call the addtocart function  
$db->addtocart($id);
}
//get the remaining set of saleproducts as table
$string5=$db->getAllSaleAsTable();
if(isset($_POST['pageno'])){
$pgno= $_POST['pageno'];
// get all the catalog products as table for the page clicked
$string6=$db->getAllCatalogAsTable($pgno);


}
else
{
//the initial default home page
$pgno=0;
$string6=$db->getAllCatalogAsTable($pgno);
}


?>
<!-- displaying the sale and catalog in tabular forms--> 
<div class="container"><img src="sale_tag_256.png"\><section>SALE<?php echo $string5; ?></section><hr>
<section><h1 style="color:#337ab7;margin-left:45%">CATALOG</h1><div><?php echo $string6; ?></div>
<form action='Index.php' method='post'>
<table><tr><td><button class='btn btn-primary ' type='submit' name='pageno' value=0>0</button></td>
<td><button class='btn btn-primary' type='submit' name='pageno' value=1>1</button></td>
<td><button class='btn btn-primary' type='submit' name='pageno' value=2>2</button></td></tr></table></form></section>
</div>

 
   
