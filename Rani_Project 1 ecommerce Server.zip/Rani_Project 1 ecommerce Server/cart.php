<?php 
require_once "header.php";
session_start();
global $string2;
//getting an instance of database
 $db = DB::getInstance();
 //getting all cart items as table
 $string2=$db->getAllCartsAsTable();
//checking if "deletefromcart" was clicked 
 if(isset($_POST['deletefromcart'])){
  $id= $_POST['deletefromcart'];
//if yes then call the deletefromcart function  
$db->deletefromcart($id);
//after deleting that item that get all left cart items as table
$string2=$db->getAllCartsAsTable();


}
////checking if "emptycart" was clicked 
if(isset($_POST['emptycart'])){
//if yes then call the emptycart function  
$db->emptycart();
echo "<h2 style='color:red'>EMPTY CART</h2>";
    }


?>
<!--display cart in a division-->
 <div><?php echo "<div class='cart'>".$string2."</div>"; ?></div>