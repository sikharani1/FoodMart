<?php


require_once ("header.php");

$db= new DB();


//creating a product class
class Product
    {


//---------------------------Function to return the number of products that are on sale----------------------------------
        public static function getNumberOfSaleProducts()
        {
            $db = DB::getInstance();
              //calling showsale function to get sale products                                                                                             
            $rows = $db->showsale();
            //echo count($rows);
            return count($rows);
        }

//---------------------function to upload a product image to the server in the assets folder---------------------------------------------------
        public static function uploadProductImage()
        {
            $targetdir = "assets/";
           
            $targetfile = $targetdir.basename($_FILES["ProductImage"]["name"]);

            $imageType = pathinfo($targetfile, PATHINFO_EXTENSION);
          //  echo "image->$imageType";
            if ($imageType != "jpg" && $imageType != "png" && $imageType != "jpeg") {
                echo "<script type='text/javascript'> 
             
                            function imagetypeerror()
                            {
                            setTimeout(
                            function()
                            {
                            alertify.alert(
                            'Incorrect image type!',
                            content:'Sorry, only JPG, JPEG, PNG  are allowed !'
                            );
                            },
                            400);
                                }
                            imagetypeerror();
                        </script>";
            } else {
                //echo $imageType;
                move_uploaded_file($_FILES["ProductImage"]["tmp_name"], $targetfile);
            }
            
            return basename($_FILES["ProductImage"]["name"]);
        }

//---------------------------function to add a new product to the product table from the admin page---------------------------------------------------------
      
        public static function addProduct()
        {
            $db = DB::getInstance();
            $discounted_items = Product::getNumberOfSaleProducts();
			//echo "no of discounted items->".$discounted_items;
//sanitize the input fields to ensure security
//calling sanitizeString function            
            $product_name = sanitizeString($_POST['name']);
            $product_desc = $_POST['description'];
            $product_price = sanitizeString($_POST['price']);
            $product_quantity = sanitizeString($_POST['quantity']);
            $product_SalePrice = sanitizeString($_POST['saleprice']);
            
            if (!empty($_FILES['ProductImage'])) {
            //calling uploadProductImage function
                $ProductImage = Product::uploadProductImage();
            }
            //adding a sale product
              //also the constraints on the number of discounted products i.e between 3 to 5 taken into consideration
        if (isset($_POST['saleprice']) && doubleval($_POST['saleprice']) != 0) {
                //max number of discounted items reached - prevent admin from adding this item
                if ($discounted_items == 5) {
               // echo "maximum products reached";
        		echo "<script type='text/javascript'> 
                            function maxdiscounterror(){ 
                            setTimeout(
                            function()
                            {
                            alertify.alert(
                         'Too many products on sale,You can only have 5 products on sale !'
                            );
                                    },
                                    400);
                                }
                            maxdiscounterror();
                        </script>";
                        
                } 
                else
                 {
                  //if within the max discounted items allowed - check if the sale and product prices added are valid
                    if (doubleval($_POST['saleprice']) < doubleval($_POST['price'])) {
                   
                        //add the product to the products table
                        $querystring = "INSERT INTO Product(ProductName,ProductDesc,ImageName,OriginalPrice,SalePrice,Quantity) VALUES (?,?,?,?,?,?)";
                        if($stmt = $db->connection->prepare($querystring)){
            		//	echo "connection done,adding to sale";
            			$insertId=-1;
                		$stmt->bind_param('sssddi',$product_name,$product_desc,$ProductImage,$product_price,$product_SalePrice,$product_quantity);
               			 $stmt->execute();
               			 $stmt->store_result();
              		  $insertId = $stmt->insert_id;
              		  }
              		 // echo "$insertId->".$insertId;
            		}
            		else{ //invalid price
                        echo "<script type='text/javascript'> 
                        function salepriceerror(){ 
                           setTimeout(
                           function()
                           {
                           alertify.alert('Wrong!The sale price must be lesser than the products price !'
                           );
                                },
                                400);
                            }
                        salepriceerror();
                        </script>";
                    }
            }
        }
                       
    else {
                //not a sale product

                
                //echo "trying to add catalog product";
                 $querystring = "INSERT INTO Product(ProductName,ProductDesc,ImageName,OriginalPrice,SalePrice,Quantity) VALUES (?,?,?,?,0.0,?)";
                if($stmt = $db->connection->prepare($querystring)){
            	//echo "connection done adding to catalog";
            	 $insertId = -1;
                $stmt->bind_param('sssdi',$product_name,$product_desc,$ProductImage,$product_price,$product_quantity);
                $stmt->execute();
                $stmt->store_result();
                 $insertId = $stmt->insert_id;
               
              //  echo "$insertId->".$insertId;
                    if ($insertId>0) {
                    echo "<script type='text/javascript'> 
                        function productaddsuccess(){ 
                            setTimeout(
                            function(){
                            alertify.alert(
                      'Success !The product was successfully added to the system !'
                            );
                                },
                                400);
                            }
                        productaddsuccess();
                        </script>";
                }
            	
            }

            
            }
        }
        

//--------------------------------------function to edit a product already in the products table-------------------------------------------------------

        public static function editProduct()
        {
            $db = DB::getInstance();
            $discounted_items = Product::getNumberOfSaleProducts();
			//echo "discounted items=>".$discounted_items;
            //check if discounted items constraint violated
            $product_id = sanitizeString($_POST['editId']);
            $product_name = sanitizeString($_POST['editName']);
         	$product_desc = $_POST['editDescription'];
            $product_price = sanitizeString($_POST['editPrice']);
            $product_quantity = sanitizeString($_POST['editQuantity']);
            $product_SalePrice = sanitizeString($_POST['editSalePrice']);
          //	echo "productid=>".$product_id."<br>";
           //echo "productname=>".$product_name;
        if (!empty($_FILES['ProductImage'])) {
                $ProductImage = Product::uploadProductImage();
        }
			 $rows = array();
            $querystring = "SELECT SalePrice FROM Product WHERE ProductID=?";
        //check if the product sale price and actual prices are correct
            if($product_price<$product_SalePrice)
        	{
            	 echo "<script type='text/javascript'> 
                        function discountpriceerror(){ 
                            setTimeout(
                            function(){
                            alertify.alert('Trying to update Wrong! product price.'
                            );
                                },
                                400);
                            }
                        discountpriceerror();
                        </script>";
           }
        else
        {
        		
					            

            if($stmt = $db->connection->prepare("SELECT SalePrice FROM Product WHERE ProductID=?")){
                   // 	echo "connection set";
                    //	echo "productid=>".$product_id;
            	$stmt->bind_param('i', intval($product_id));
                $stmt->execute();
               
                $stmt->bind_result($sale_price);
                 $stmt->store_result();
                $nrows=$stmt->num_rows;
             //  echo "number of rows selected->".$nrows."<br\>";
               
                    while($stmt->fetch()){
                        $rows[] = array('sprice'=>$sale_price);
                        
                    }
                
            }
             $sale_price = $rows[0]['sprice'];
          //  echo "saleprice->".$sale_price;
           // echo "product_SalePrice->".$product_SalePrice;
            
          
           


            //shouldn't be below 3 or above 5 i.e should not allow an edit if the constraint on the number of discounted items is violated 
            if (($discounted_items == 5 && $product_SalePrice > 0 && $sale_price == 0 && $product_quantity>=1) ||
                ($discounted_items == 3 && $product_SalePrice == 0 && $sale_price > 0 && $product_quantity>=1)
            ) {
               
              //echo "<h1 style='color:red'>initial discount price".$sale_price."new disc price".$product_SalePrice."</h2>";
                echo "<script type='text/javascript'> 
                        function discountconstraintserror(){ 
                            setTimeout(
                            function(){
                            alertify.alert(
                            'Wrong!,
                           You can only have between 3 and 5 products on sale !'
                            );
                                },
                                400);
                            }
                        discountconstraintserror();
                        </script>";
                        exit();
            } 
            else
            {
           // echo "trying to update";
                $querystring = "UPDATE Product SET ProductName= ?,ProductDesc=?,ImageName=?, OriginalPrice = ?,SalePrice = ?,Quantity = ? WHERE ProductID=?";
                
                 if($stmt = $db->connection->prepare($querystring)){
            	//echo "connection done";
               // echo "Product sale price=".$product_SalePrice;
                $stmt->bind_param('sssddii',$product_name, $product_desc, $ProductImage,doubleval($product_price),doubleval($product_SalePrice), $product_quantity, intval($product_id));
            
                $stmt->execute();
                $stmt->store_result();
                $numRows = $stmt->affected_rows;
                //echo "numberofrows->".$numRows;
            	
                echo "<script type='text/javascript'> 
                        function producteditsuccess(){ 
                            setTimeout(
                            function(){
                            alertify.alert(
                          'Success,The item was successfully updated !'
                            );
                                },
                                400);
                            }
                        producteditsuccess();
                        </script>";
                }
                        
            }
        }
    }
 }



?>

